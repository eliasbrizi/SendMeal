package com.B3B.sendmeal.domain;

public enum EstadoPedido {
    PENDIENTE,ENVIADO,ACEPTADO,RECHAZADO,EN_PREPARACION,EN_ENVIO,ENTREGADO,CANCELADO;
}
