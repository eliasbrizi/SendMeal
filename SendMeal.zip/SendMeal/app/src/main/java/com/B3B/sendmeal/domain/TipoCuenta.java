package com.B3B.sendmeal.domain;

public enum TipoCuenta
{
    BASICA,PREMIUM,FULL;
}
